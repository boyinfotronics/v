<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************ */

require_once('data/CRMEntity.php');
include_once 'include/Webservices/Create.php';

function info_mapi_user_reg($element) {

    if (strcmp($element['user_password'],$element['confirm_password'])) {
        throw new WebServiceException(WebServiceErrorCode::$ACCESSDENIED, "Password doesn't match!!!");
    }

    global $adb;

    $checkres = $adb->pquery("SELECT id FROM vtiger_users WHERE user_name=?", array($element['user_name']));
	if($checkres && $adb->num_rows($checkres) > 0){
        throw new WebServiceException(WebServiceErrorCode::$ACCESSDENIED, "Username already exists."); 
    }

    $checkres = $adb->pquery("SELECT id FROM vtiger_users WHERE email1=?", array($element['email1']));
	if($checkres && $adb->num_rows($checkres) > 0){
        throw new WebServiceException(WebServiceErrorCode::$ACCESSDENIED, "E-mail already exists."); 
    }
    
    $elementType = "Users";
    $user = CRMEntity::getInstance('Users');
	$user->id=$user->getActiveAdminId();
	$user->retrieve_entity_info($user->id, 'Users');

    $element['roleid'] = "H2";
    $element['is_admin'] = "";
    $element['date_format'] = "dd-mm-yyyy";
    $element['time_zone'] = "Asia/Bangkok";
    $element['language'] = "en_us";

    $record=vtws_create($elementType, $element, $user);

    if($record){
			return $record;
	}

    throw new WebServiceException(WebServiceErrorCode::$ACCESSDENIED, "Error!!!");   
}
?>