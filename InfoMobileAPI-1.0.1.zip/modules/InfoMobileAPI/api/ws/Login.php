<?php
	require_once('data/CRMEntity.php');
	require_once('../../Encode.php');

	function info_mapi_login($username,$pwd){
		
		$user = new Users();
		$userId = $user->retrieve_user_id($username);

		$current_user = CRMEntity::getInstance('Users');
		$current_user->column_fields['user_name'] = $username;
		
		if(!$current_user->doLogin($pwd)) {
			throw new WebServiceException(WebServiceErrorCode::$INVALIDUSERPWD,"Invalid username or password");
		}
		
		$user = $user->retrieveCurrentUserInfoFromFile($userId);
		if($user->status != 'Inactive'){
			return $user;
		}
		throw new WebServiceException(WebServiceErrorCode::$AUTHREQUIRED,'Given user is inactive');
	}
	
?>
