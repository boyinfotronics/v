<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************ */

	require_once("include/Webservices/QueryParser.php");

    function info_mapi_getwithdescribe($id,$user){
		
		static $vtws_query_cache = array();	

		global $log,$adb;
		$idList = vtws_getIdComponents($id);
		$webserviceObject = VtigerWebserviceObject::fromId($adb,$idList[0]);
		$handlerPath = $webserviceObject->getHandlerPath();
		$handlerClass = $webserviceObject->getHandlerClass();
		
		require_once $handlerPath;
		
		$handler = new $handlerClass($webserviceObject,$user,$adb,$log);
		$meta = $handler->getMeta();
		$moduleName = $meta->getObjectEntityName($id);

		$q = 'SELECT * FROM '.$moduleName.' WHERE id='.$id.';';

		if(!isset($vtws_create_cache[$moduleName]['webserviceobject'])) {
			$webserviceObject = VtigerWebserviceObject::fromQuery($adb,$q);
			$vtws_query_cache[$moduleName]['webserviceobject'] = $webserviceObject;
		} else {
			$webserviceObject = $vtws_query_cache[$moduleName]['webserviceobject'];
		}

		// Cache the instance for re-use
		if(!isset($vtws_query_cache[$moduleName]['handler'])) {
			$handler = new $handlerClass($webserviceObject,$user,$adb,$log);
			$vtws_query_cache[$moduleName]['handler'] = $handler;
		} else {
			$handler = $vtws_query_cache[$moduleName]['handler'];
		}
		// END	

		// Cache the instance for re-use
		if(!isset($vtws_query_cache[$moduleName]['meta'])) {
			$meta = $handler->getMeta();
			$vtws_query_cache[$moduleName]['meta'] = $meta;
		} else {
			$meta = $vtws_query_cache[$moduleName]['meta'];
		}
		// END
		
		$types = vtws_listtypes(null, $user);
		if(!in_array($moduleName,$types['types'])){
			throw new WebServiceException(WebServiceErrorCode::$ACCESSDENIED,"Permission to perform the operation is denied");
		}

		if(!$meta->hasReadAccess()){
			throw new WebServiceException(WebServiceErrorCode::$ACCESSDENIED,"Permission to read is denied");
		}
		
		$entity = $handler->describe($moduleName);
		$result = $handler->query($q);

		$i = 0;

		foreach ($result[0] as $key => $value){
			$entity['fields'][$i]['value'] = $value;
			$i++;
		}
		
		VTWS_PreserveGlobal::flush();
		return $entity;
	}


?>